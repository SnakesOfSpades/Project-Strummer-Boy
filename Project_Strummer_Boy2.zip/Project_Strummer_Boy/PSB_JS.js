var go = document.getElementById('lowere1'), audio = null;

//First Fret
function lowerE1() {
    audio = new Audio("./sounds/Lower-E1.mp3");
    audio.play();
}

function a1() {
    audio = new Audio("./sounds/A1.mp3");
    audio.play();
}

function d1() {
    audio = new Audio("./sounds/D1.mp3");
    audio.play();
}

function g1() {
    audio = new Audio("./sounds/G1.mp3");
    audio.play();
}

function b1() {
    audio = new Audio("./sounds/B1.mp3");
    audio.play();
}

function upperE1() {
    audio = new Audio("./sounds/Upper-E1.mp3");
    audio.play();
}

//Second Fret
function lowerE2() {
    audio = new Audio("./sounds/Lower-E2.mp3");
    audio.play();
}

function a2() {
    audio = new Audio("./sounds/A2.mp3");
    audio.play();
}

function d2() {
    audio = new Audio("./sounds/D2.mp3");
    audio.play();
}

function g2() {
    audio = new Audio("./sounds/G2.mp3");
    audio.play();
}

function b2() {
    audio = new Audio("./sounds/B2.mp3");
    audio.play();
}

function upperE2() {
    audio = new Audio("./sounds/Upper-E2.mp3");
    audio.play();
}